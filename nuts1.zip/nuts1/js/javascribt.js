
$( "#q" ).mouseenter(function() {
  $(".Q").animate({
  
    marginLeft:"100px",
    
    
  }, 1000 );
  });
  $( "#q" ).mouseleave(function() {
    $(".Q").animate({
    
      marginLeft:"0",
      
      
    }, 1000 );
    });
    $( "#q" ).mouseenter(function() {
      $(".q2").animate({
      
        marginLeft:"100px",
        
        
      }, 2000 );
      });
      $( "#q" ).mouseleave(function() {
        $(".q2").animate({
        
          marginLeft:"0",
          
          
        }, 2000 );
        });
 
        $( "#q" ).mouseenter(function() {
          $(".q1").animate({
          
            marginLeft:"50px",
            
            
          }, 2000 );
          });
          $( "#q" ).mouseleave(function() {
            $(".q1").animate({
            
              marginLeft:"0",
              
              
            }, 2000 );
            });
     //////////////////////////
  

            $( "#q1" ).mouseenter(function() {
              $(".Q1").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q1" ).mouseleave(function() {
                $(".Q1").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q1" ).mouseenter(function() {
                  $(".PP1").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q1" ).mouseleave(function() {
                    $(".PP1").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q1" ).mouseenter(function() {
                      $(".P1").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q1" ).mouseleave(function() {
                        $(".P1").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q2" ).mouseenter(function() {
              $(".Q2").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q2" ).mouseleave(function() {
                $(".Q2").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q2" ).mouseenter(function() {
                  $(".PP2").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q2" ).mouseleave(function() {
                    $(".PP2").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q2" ).mouseenter(function() {
                      $(".P2").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q2" ).mouseleave(function() {
                        $(".P2").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q3" ).mouseenter(function() {
              $(".Q3").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q3" ).mouseleave(function() {
                $(".Q3").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q3" ).mouseenter(function() {
                  $(".PP3").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q3" ).mouseleave(function() {
                    $(".PP3").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q3" ).mouseenter(function() {
                      $(".P3").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q3" ).mouseleave(function() {
                        $(".P3").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q4" ).mouseenter(function() {
              $(".Q4").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q4" ).mouseleave(function() {
                $(".Q4").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q4" ).mouseenter(function() {
                  $(".PP4").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q4" ).mouseleave(function() {
                    $(".PP4").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q4" ).mouseenter(function() {
                      $(".P4").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q4" ).mouseleave(function() {
                        $(".P4").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q5" ).mouseenter(function() {
              $(".Q5").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q5" ).mouseleave(function() {
                $(".Q5").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q5" ).mouseenter(function() {
                  $(".PP5").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q5" ).mouseleave(function() {
                    $(".PP5").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q5" ).mouseenter(function() {
                      $(".P5").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q5" ).mouseleave(function() {
                        $(".P5").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q6" ).mouseenter(function() {
              $(".Q6").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q6" ).mouseleave(function() {
                $(".Q6").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q6" ).mouseenter(function() {
                  $(".PP6").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q6" ).mouseleave(function() {
                    $(".PP6").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q6" ).mouseenter(function() {
                      $(".P6").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q6" ).mouseleave(function() {
                        $(".P6").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q7" ).mouseenter(function() {
              $(".Q7").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q7" ).mouseleave(function() {
                $(".Q7").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q7" ).mouseenter(function() {
                  $(".PP7").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q7" ).mouseleave(function() {
                    $(".PP7").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q7" ).mouseenter(function() {
                      $(".P7").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q7" ).mouseleave(function() {
                        $(".P7").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q8" ).mouseenter(function() {
              $(".Q8").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q8" ).mouseleave(function() {
                $(".Q8").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q8" ).mouseenter(function() {
                  $(".PP8").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q8" ).mouseleave(function() {
                    $(".PP8").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q8" ).mouseenter(function() {
                      $(".P8").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q8" ).mouseleave(function() {
                        $(".P8").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q9" ).mouseenter(function() {
              $(".Q9").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q9" ).mouseleave(function() {
                $(".Q9").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q9" ).mouseenter(function() {
                  $(".PP9").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q9" ).mouseleave(function() {
                    $(".PP9").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q9" ).mouseenter(function() {
                      $(".P9").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q9" ).mouseleave(function() {
                        $(".P9").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q10" ).mouseenter(function() {
              $(".Q10").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q10" ).mouseleave(function() {
                $(".Q10").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q10" ).mouseenter(function() {
                  $(".PP10").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q10" ).mouseleave(function() {
                    $(".PP10").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q10" ).mouseenter(function() {
                      $(".P10").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q10" ).mouseleave(function() {
                        $(".P10").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                 ////////////////////////
               //////////////////////////
  

            $( "#q11" ).mouseenter(function() {
              $(".Q11").animate({
              
                marginLeft:"100px",
                
                
              }, 1000 );
              });
              $( "#q11" ).mouseleave(function() {
                $(".Q11").animate({
                
                  marginLeft:"0",
                  
                  
                }, 1000 );
                });
                $( "#q11" ).mouseenter(function() {
                  $(".PP11").animate({
                  
                    marginLeft:"100px",
                    
                    
                  }, 2000 );
                  });
                  $( "#q11" ).mouseleave(function() {
                    $(".PP11").animate({
                    
                      marginLeft:"0",
                      
                      
                    }, 2000 );
                    });
             
                    $( "#q11" ).mouseenter(function() {
                      $(".P11").animate({
                      
                        marginLeft:"50px",
                        
                        
                      }, 2000 );
                      });
                      $( "#q11" ).mouseleave(function() {
                        $(".P11").animate({
                        
                          marginLeft:"0",
                          
                          
                        }, 2000 );
                        });
                /////////////////////////////////////////////////////////////////////////////////////////////////////
    $( "#q00" ).mouseenter(function() {
      $(".Qo").animate({
      
        marginRight:"100px",
        
        
      }, 2000 );
      });
      $( "#q00" ).mouseleave(function() {
        $(".Qo").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q00" ).mouseenter(function() {
          $(".q11").animate({
          
            marginRight:"50px",
            
            
          }, 2000 );
          });
          $( "#q00" ).mouseleave(function() {
            $(".q11").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
            $( "#q00" ).mouseenter(function() {
              $(".q22").animate({
              
                marginRight:"100px",
                
                
              }, 2000 );
              });
              $( "#q00" ).mouseleave(function() {
                $(".q22").animate({
                
                  marginRight:"0",
                  
                  
                }, 2000 );
                });
/////////////////////////            

$( "#q111" ).mouseenter(function() {
  $(".Q11").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q111" ).mouseleave(function() {
    $(".Q11").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q111" ).mouseenter(function() {
      $(".P1110").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q111" ).mouseleave(function() {
        $(".P1110").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q111" ).mouseenter(function() {
          $(".PP1110").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q111" ).mouseleave(function() {
            $(".PP1110").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q222" ).mouseenter(function() {
  $(".Q22").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q222" ).mouseleave(function() {
    $(".Q22").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q222" ).mouseenter(function() {
      $(".P222").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q222" ).mouseleave(function() {
        $(".P222").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q222" ).mouseenter(function() {
          $(".PP222").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q222" ).mouseleave(function() {
            $(".PP222").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q333" ).mouseenter(function() {
  $(".Q33").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q333" ).mouseleave(function() {
    $(".Q33").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q333" ).mouseenter(function() {
      $(".P333").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q333" ).mouseleave(function() {
        $(".P333").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q333" ).mouseenter(function() {
          $(".PP333").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q333" ).mouseleave(function() {
            $(".PP333").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q444" ).mouseenter(function() {
  $(".Q44").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q444" ).mouseleave(function() {
    $(".Q44").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q444" ).mouseenter(function() {
      $(".P444").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q444" ).mouseleave(function() {
        $(".P444").animate({
              marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q444" ).mouseenter(function() {
          $(".PP444").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q444" ).mouseleave(function() {
            $(".PP444").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q555" ).mouseenter(function() {
  $(".Q55").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q555" ).mouseleave(function() {
    $(".Q55").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q555" ).mouseenter(function() {
      $(".P555").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q555" ).mouseleave(function() {
        $(".P555").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q555" ).mouseenter(function() {
          $(".PP555").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q555" ).mouseleave(function() {
            $(".PP555").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q666" ).mouseenter(function() {
  $(".Q66").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q666" ).mouseleave(function() {
    $(".Q66").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q666" ).mouseenter(function() {
      $(".P666").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q666" ).mouseleave(function() {
        $(".P666").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q666" ).mouseenter(function() {
          $(".PP666").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q666" ).mouseleave(function() {
            $(".PP666").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q777" ).mouseenter(function() {
  $(".Q77").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q777" ).mouseleave(function() {
    $(".Q77").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q777" ).mouseenter(function() {
      $(".P777").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q777" ).mouseleave(function() {
        $(".P777").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q777" ).mouseenter(function() {
          $(".PP777").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q777" ).mouseleave(function() {
            $(".PP777").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q888" ).mouseenter(function() {
  $(".Q88").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q888" ).mouseleave(function() {
    $(".Q88").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q888" ).mouseenter(function() {
      $(".P888").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q888" ).mouseleave(function() {
        $(".P888").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q888" ).mouseenter(function() {
          $(".PP888").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q888" ).mouseleave(function() {
            $(".PP888").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q999" ).mouseenter(function() {
  $(".Q99").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q999" ).mouseleave(function() {
    $(".Q99").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q999" ).mouseenter(function() {
      $(".P999").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q999" ).mouseleave(function() {
        $(".P999").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q999" ).mouseenter(function() {
          $(".PP999").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q999" ).mouseleave(function() {
            $(".PP999").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q111" ).mouseenter(function() {
  $(".Q2").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q111" ).mouseleave(function() {
    $(".Q2").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q111" ).mouseenter(function() {
      $(".P111").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q111" ).mouseleave(function() {
        $(".P111").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q111" ).mouseenter(function() {
          $(".PP111").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q111" ).mouseleave(function() {
            $(".PP111").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

$( "#q111" ).mouseenter(function() {
  $(".Q2").animate({
  
    marginRight:"100px",
    
    
  }, 2000 );
  });
  $( "#q111" ).mouseleave(function() {
    $(".Q2").animate({
    
      marginRight:"0",
      
      
    }, 2000 );
    });
    $( "#q111" ).mouseenter(function() {
      $(".P111").animate({
      
        marginRight:"50px",
        
        
      }, 2000 );
      });
      $( "#q111" ).mouseleave(function() {
        $(".P111").animate({
        
          marginRight:"0",
          
          
        }, 2000 );
        });
        $( "#q111" ).mouseenter(function() {
          $(".PP111").animate({
          
            marginRight:"100px",
            
            
          }, 2000 );
          });
          $( "#q111" ).mouseleave(function() {
            $(".PP111").animate({
            
              marginRight:"0",
              
              
            }, 2000 );
            });
/////////////////////////            

 /*      

       
$( "#q" ).mouseenter(function() {
    $(".bbb").animate({
    
      opacity: 0.9,
    
      
    }, 1000 );
    });
      
$( "#q" ).mouseleave(function() {
$(".i").animate({

  opacity: 0.9,
  width:"100%",height:"100%",
  
}, 1000 );
});        
$( "#q1" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"98%",
  
}, 1000 );
});
      
$( "#q1" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});       
$( "#q2" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"100%",
  
}, 1000 );
});
      
$( "#q2" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"100%",
  
}, 1000 );
});     
$( "#q3" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"100%",
  
}, 1000 );
});
      
$( "#q3" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});
   
$( "#q4" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"98%",height:"98%",
  
}, 1000 );
});
      
$( "#q4" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"100%",
  
}, 1000 );
});
   
$( "#q5" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"98%",
  
}, 1000 );
});
      
$( "#q5" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});
   
$( "#q6" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"98%",height:"98%",
  
}, 1000 );
});
      
$( "#q6" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});
   
$( "#q7" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"100%",
  
}, 1000 );
});
      
$( "#q7" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});
   
$( "#q8" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"98%",
  
}, 1000 );
});
      
$( "#q8" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});
   
$( "#q9" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"100%",height:"100%",
  
}, 1000 );
});
      
$( "#q9" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
}, 1000 );
});
   
$( "#q10" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"98%",height:"98%",
  
}, 1000 );
});
      
$( "#q10" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});
   
$( "#q11" ).mouseenter(function() {
$(this).animate({

  opacity: 0.7,
  width:"98%",height:"98%",
  
}, 1000 );
});
      
$( "#q11" ).mouseleave(function() {
$(this).animate({

  opacity: 0.9,
  width:"100%",height:"98%",
  
}, 1000 );
});*/


  



  function imagefun() {
        var name = "k";
       var name1="m";
     
        
        if (name=="k") {
console.log(10000);
         
    
document.getElementById("b1").style.color='black';
document.getElementById("b2").style.backgroundColor='black';
document.getElementById("b2").style.backgroundImage ;

document.getElementById("b2").style.color='white';
document.getElementById("q").style.backgroundColor='black';
document.getElementById("q").style.borderBottomRightRadius='40px';
document.getElementById("b2").style.backgroundColor='black';
document.getElementById("q1").style.backgroundColor='black';
document.getElementById("q1").style.borderBottomRight='40px';
document.getElementById("q-").style.color='white';
document.getElementById("q2").style.backgroundColor='black';
document.getElementById("q2").style.borderBottomRightRadius='40px';
document.getElementById("q3").style.backgroundColor='black';
document.getElementById("q3").style.borderBottomRightRadius='40px';
document.getElementById("q4").style.backgroundColor='black';
document.getElementById("q4").style.borderBottomRightRadius='40px';
document.getElementById("q5").style.backgroundColor='black';
document.getElementById("q5").style.borderBottomRightRadius='40px';
document.getElementById("q6").style.backgroundColor='black';
document.getElementById("q6").style.borderBottomRightRadius='40px';
document.getElementById("q7").style.backgroundColor='black';
document.getElementById("q7").style.borderBottomRightRadius='40px';
document.getElementById("q8").style.backgroundColor='black';
document.getElementById("q8").style.borderBottomRightRadius='40px';
document.getElementById("q9").style.backgroundColor='black';
document.getElementById("q9").style.borderBottomRightRadius='40px';
document.getElementById("q10").style.backgroundColor='black';
document.getElementById("q10").style.borderBottomRightRadius='40px';
document.getElementById("q11").style.backgroundColor='black';
document.getElementById("q11").style.borderBottomRightRadius='40px';
document.getElementById("q-").style.color='white';
document.getElementById("qq").style.color='white';
document.getElementById("qw").style.color='white';
document.getElementById("qe").style.color='white';
document.getElementById("qr").style.color='white';
document.getElementById("qt").style.color='white';
document.getElementById("qy").style.color='white';
document.getElementById("qu").style.color='white';
document.getElementById("qi").style.color='white';
document.getElementById("qo").style.color='white';
document.getElementById("qa").style.color='white';
document.getElementById("q--").style.color='white';
document.getElementById("n").style.opacity='1'
     document.getElementById("n1").style.opacity='0'
        }
       
    }   
    
    
function firstfun(){
var name1="m";
if (name1=="m") {
       
       document.getElementById("b2").style.backgroundColor='white';
      
     
     document.getElementById("n").style.opacity='0'
     document.getElementById("n1").style.opacity='1'
document.getElementById("b1").style.color='black';
document.getElementById("b2").style.backgroundColor='white';

document.getElementById("b2").style.color='black';
document.getElementById("q").style.backgroundColor='white';
document.getElementById("q").style.borderRadius='10px';
document.getElementById("b2").style.backgroundColor='white';
document.getElementById("q1").style.backgroundColor='white';
document.getElementById("q1").style.borderRadius='10px';
document.getElementById("q-").style.color='black';
document.getElementById("q2").style.backgroundColor='white';
document.getElementById("q2").style.borderRadius='10px';
document.getElementById("q3").style.backgroundColor='white';
document.getElementById("q3").style.borderRadius='10px';
document.getElementById("q4").style.backgroundColor='white';
document.getElementById("q4").style.borderRadius='10px';
document.getElementById("q5").style.backgroundColor='white';
document.getElementById("q5").style.borderRadius='10px';
document.getElementById("q6").style.backgroundColor='white';
document.getElementById("q6").style.borderRadius='10px';
document.getElementById("q7").style.backgroundColor='white';
document.getElementById("q7").style.borderRadius='10px';
document.getElementById("q8").style.backgroundColor='white';
document.getElementById("q8").style.borderRadius='10px';
document.getElementById("q9").style.backgroundColor='white';
document.getElementById("q9").style.borderRadius='10px';
document.getElementById("q10").style.backgroundColor='white';
document.getElementById("q10").style.borderRadius='10px';
document.getElementById("q11").style.backgroundColor='white';
document.getElementById("q11").style.borderRadius='10px';
document.getElementById("q-").style.color='black';
document.getElementById("qq").style.color='black';
document.getElementById("qw").style.color='black';
document.getElementById("qe").style.color='black';
document.getElementById("qr").style.color='black';
document.getElementById("qt").style.color='black';
document.getElementById("qy").style.color='black';
document.getElementById("qu").style.color='black';
document.getElementById("qi").style.color='black';
document.getElementById("qo").style.color='black';
document.getElementById("qa").style.color='black';
document.getElementById("q--").style.color='black';
         
       }
} 2000

/*function musein(){
var x="y";
if(x=='y'){
document.getElementById("q").style.color='red';
document.getElementById("q").style.width='98%';


} 2000;

}
function museout(){
var y="x";
if(y=="x"){

document.getElementById('q').style.color='red';
document.getElementById('q').style.width='100%';
}

}*/


