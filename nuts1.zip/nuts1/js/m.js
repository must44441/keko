

let carts=document.getElementById('#add-cart')
 
for(let i=0; i < Carts.length; i++){
 console.log("my lobb");
 carts[i].addEventListener('click',()=>{
    CartN(products[i]);
}
  )
 }
 let products=[
   { 
     name:'CASHEW',
     tag:'cashew',
     price:16000,
     inCART:0
   },
     { 
     name:'HAZELNUTS',
     tag:'hazelnuts',
     price:16000,
     inCART:0
   }
 ];
 
 function onloadCartN(){
   let pn=localStorage.getItem('CartN');
   if (pn){
     document.querySelector('.zero').textContent=pn;
   }
 }
 function CartN(product){
   console.log("hi",product);
   let pn=localStorage.getItem('CartN')
   /* console.log("pn");
   console.log(typeof pn);
  
 ;*/ localStorage.setItem('CartN',1)
  pn=parseInt(pn);
  if (pn){
    localStorage.setItem('CartN',pn+1);
    document.querySelector('.zero').textContent=pn+1;
  } else {
    localStorage.setItem('CartN',1);
    document.querySelector('.zero').textContent=1
  }
 setItem(product);
 }
function setItem(product){
  console.log("hi2");
  console.log("hi3",product);
 product.inCART=1;
  let cartA = {
    [product.tag]:product
  }
  
 
localStorage.setItem("productsinCART",JSON.stringify(cartA) )
}
  onloadCartN();
 